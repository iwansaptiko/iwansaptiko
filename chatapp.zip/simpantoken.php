<?php

include_once("dbconnect.php");
$nama=$_GET['nama'];
$tokenku=$_GET['token'];
$res=$mysqli->query("select * from daftarusers where token='$tokenku'");
$count=mysqli_num_rows($res);

if($count==0){
	if($tokenku!=null ) {
         	if($tokenku!='') {
             $res1=$mysqli->query("insert into daftarusers (nama,token) value('$nama','$tokenku')");
	}else { echo "kosong";}
			
	} else {
	   echo "Null";
	}
} 
//else {
//    $row=mysqli_fetch_assoc($res);
    //$topic=$row['topic'];
//    $nama=$row['nama'];
//    if($row['nama']=='') {
//    $res1=$mysqli->query("delete from daftarusers where token='$tokenku'");    
//    $res1=$mysqli->query("insert into daftarusers (nama,token) value('$nama','$tokenku')");
//    } else {
//    $res1=$mysqli->query("delete from daftarusers where token='$tokenku'");    
//    $res1=$mysqli->query("insert into daftarusers (nama,token) value('$nama','$tokenku')");
 //   }
//}
//echo $topic;

?>