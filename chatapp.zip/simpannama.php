<?php
include_once("dbconnect.php");
$nama=$_GET['nama'];

$res=$mysqli->query("update daftarusers nama='$nama' where token='$tokenku'");
?>