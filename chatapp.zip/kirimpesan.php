<?php
        $topic =  "chatapp99";
        if(isset($_GET['pesan'])) {
		  $pesan=$_GET['pesan'];
		  $pengirim=$_GET['pengirim'];
		  $waktu=$_GET['waktu'];
		  $gambar=$_GET['gambar'];
		} else {
			$pesan="Percobaan";
			$pengirim="Pengirim";
		  $waktu="waktu";
		  $gambar="gambar";
		}
        $url = 'https://fcm.googleapis.com/fcm/send';
        $api_key = 'AAAAR57p_RY:APA91bGyrX7X73rFlZyIQQTKW3osvnvkdMwVfM8Wb8V8OunqZvrQYwscpImE-MX9UzgZNOiHmJLGpvom55yM5IOl9-537mNK4PWEVaOn7TMkQLGx6uoM4OIMhYRkXb-GdPeA6Y1kgWJS';
        
        $content="Billing No. 00123 has been Printed";
        $title="Billing Report";
      $notification_data = array(
            'pesan'               => $pesan,
			'pengirim'               => $pengirim,
			'waktu'               => $waktu,
			'gambar'               => $gambar,
        );             
    
      $notification = array(
            'title'                 => $title,
            'body'                  => $pesan,
            'content_available'     => true,
            'android_channel_id'    => 'cafe_02',
            'click_action'          => 'FLUTTER_NOTIFICATION_CLICK',
            'sound'                 => 'expload_sound.wav',
            
        );

        $post = array(
            'to'                    => '/topics/' . $topic,
            'collapse_key'          => 'type_a',
            'notification'          => $notification,
            'priority'              => 'high',
            'data'                  => $notification_data,
            'timeToLive'            => 10,
            
        );

        $payload = json_encode($post);
    $headers = array(
        'Content-Type:application/json',
        'Authorization:key='.$api_key
    );
       
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    $result = curl_exec($ch);
    if ($result === FALSE) {
        die('FCM Send Error: ' . curl_error($ch));
    }
    curl_close($ch);
    echo $result;

?>

