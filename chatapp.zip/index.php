<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
<style>
body {
  margin: 0 auto;
  max-width: 800px;
  padding: 0 20px;
}

.container {
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
}

.darker {
  border-color: #ccc;
  background-color: #ddd;
}

.container::after {
  content: "";
  clear: both;
  display: table;
}

.container img {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}

.container img.right {
  float: right;
  margin-left: 20px;
  margin-right:0;
}

.time-right {
  float: right;
  color: #aaa;
}

.time-left {
  float: left;
  color: #999;
}
button {
  font-size: 19px;
  font-family: 'Pacifico';
  overflow: visible;
  border-radius: 3px;
  position: relative;
  padding-right: 30px;
  background-color: #ECFBFF;
  border: 2px solid #A6E0EE;
  color: #2D7586;
  display: block;
  margin: 13% auto;
  height: 60px;
  width: 200px;
  cursor: pointer;
  
  &:hover {
    background-color: #DDF7FF;
    
    svg {
      transform: rotate(10deg);
      transition: transform .15s;
    }
  }
  
  svg {
    position: absolute;
    top: 13px;
    right: 25px;
    height: 30px;
    width: auto;
    transition: transform .15s;
    
    path {
      fill: #2D7586;
    }
  }
  
  &.clicked {
    background-color: #cff5b3;
    border: 2px solid #cff5b3;
    color: #6AAA3B;
    padding-right: 6px;
    animation: bounce-in .3s;
    cursor: default;

    svg {
      animation: flyaway 1.3s linear;
      top: -80px;
      right: -1000px;
      
      path {
        fill: #6AAA3B;
      }
    }
  }
}

@keyframes flyaway {
  0%   { transform: rotate(10deg);
         top: 13px;
         right: 25px;
         height: 30px; }
  5%   { transform: rotate(10deg);
         top: 13px;
         right: 0px;
         height: 30px; }
  20%   { transform: rotate(-20deg);
          top: 13px;
          right: -130px;
          height: 45px; }  
  40%   { transform: rotate(10deg);
          top: -40px;
          right: -280px;
          opacity: 1; }
  100% { transform: rotate(60deg);
         top: -200px;
         right: -1000px;
         height: 0;
         opacity: 0; }
}

@keyframes bounce-in {
  0% { padding-right: 30px; }
  40% { padding-right: 6px; }
  50% { padding-left: 30px; }
  100% { padding-left: 6px; }
}
</style>
</head>


<?php
$tokenku=$_GET['token']; //index.php?nama=user
$nama=$tokenku;
include_once("dbconnect.php");
$res=$mysqli->query("select * from daftarusers where token='$tokenku'");
$count=mysqli_num_rows($res);
$ok=1;
if($count>0){
	$row=mysqli_fetch_assoc($res);
	if($row['nama']=='') {
		$ok=0;
	}
} else{
	
}
?>

<body <?php if($ok==0){ echo 'onload="alihkan(\''.$tokenku.'\')"';} ?>>
<div id="coba">
<h2>Chat Messages</h2>


</div>
<div class="container" >
<textarea  name="pesan" id="pesan" rows="5"style="width:85%;"></textarea>

    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" id="kirimkan" xmlns:xlink="http://www.w3.org/1999/xlink" style="width:10%;" x="0px" y="0px" viewBox="0 0 512 512" enable-background="new 0 0 512 512" xml:space="preserve">
    <path id="paper-plane-icon" d="M462,54.955L355.371,437.187l-135.92-128.842L353.388,167l-179.53,124.074L50,260.973L462,54.955z
     M202.992,332.528v124.517l58.738-67.927L202.992,332.528z"></path> 
  </svg>

</div>
<br><input type="hidden" name="nama" id="nama" value="<?php echo substr($nama,140); ?>">

<span id="status">Connecting...</span>

 <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js">
    </script>
<script src="./frontend.js"></script>
<script>
function alihkan(token){
	window.open("editprofil.php?token="+token,"_self");

}
</script>
</body>
</html>