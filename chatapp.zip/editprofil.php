<!DOCTYPE html>
<html>
<?php
include_once('dbconnect.php');
if (isset($_GET['token'])) {
$token=$_GET['token'];
		$res=$mysqli->query("select * from daftarusers where token='$token'");	$count=mysqli_num_rows($res);
   if ($count>0) { 
	   $row=mysqli_fetch_assoc($res);
$id=$row['id'];
$nama=$row['nama'];
$token=$row['token'];
$gambar=$row['gambar'];
   }
}
?>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/style.css">
<link href="css/bootstrap.min.css" rel="stylesheet">
<style>
.footer1 {
background-color: #0099cc;
  color: #ffffff;
  text-align: center;
  font-size: 12px;
  padding: 15px;
}
.hid {
	display:none;
}
</style>
</head>
<body>
<div id="ruang" class="ruang-lebar" style="padding-left:0px;">
<div class="header">
  <h1>Profil</h1>
</div>
<form action="simpan.php" method="POST" enctype="multipart/form-data">
<div class="row">
   <div id="isian">
		<label for="rekam">No Rekam</label>
		<input type="text" id="rekam" name="rekam" <?php if (isset($_GET['token'])) { echo " value='".$id."' ";} ?> readonly>  
		<label for="nama">Nama</label>
		<input type="text" id="nama" name="nama" <?php if (isset($_GET['token'])) { echo " value='".$nama."' ";} ?>>
		<label for="token">Token</label>
		<input type="text" id="token" name="token" <?php if (isset($_GET['token'])) { echo " value='".$token."' ";} ?>>
	</div>

	<div  id="upload">
		<img id="image-preview" <?php if (isset($_GET['token'])) { echo " src='img2/".$id."' ";} ?> alt="image preview"/>
		<br/>
		<input type="file" id="image-source" accept="image/*;capture=camera" name="gambar"  <?php if (isset($_GET['token'])) { echo " value='".$gambar."' ";} ?> onchange="previewImage();" onclick="Android.ambilfile('<?php echo $token; ?>');">
		<input type="submit" value="Simpan">
		<input type="button" value="Baru" onclick="window.open('editprofil.php','_self')">
	</div>
  
</div>
</form>
</div>
<main>
<script>
function myFunction(x) {
  if (x.matches) { // If media query matches
    if(window.matchMedia("(max-width: 700px)")) {
		document.getElementById('isian').style.width = "100%%";
	document.getElementById('upload').style.width = "100%";
	document.getElementById('hasil').style.width = "100%";
	} else {
	document.getElementById('isian').style.width = "40%";
	document.getElementById('upload').style.width = "40%";
	document.getElementById('hasil').style.width = "100%";
	}
    
  } else {
   document.getElementById('isian').style.width = "25%";
   document.getElementById('upload').style.width = "25%";
   document.getElementById('hasil').style.width = "50%";
  }
}

var x = window.matchMedia("(max-width: 900px)")
myFunction(x) // Call listener function at run time
x.addListener(myFunction) // Attach listener function on state changes

function previewImage() {
    document.getElementById("image-preview").style.display = "block";
    var oFReader = new FileReader();
     oFReader.readAsDataURL(document.getElementById("image-source").files[0]);

    oFReader.onload = function(oFREvent) {
      document.getElementById("image-preview").src = oFREvent.target.result;
    };
  };
  function ambilmenu() {
	if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                 document.getElementById('hasil').innerHTML=this.responseText;
            }
        };
		   
        xmlhttp.open("GET","ambilmenu.php",true);
        xmlhttp.send();
}
function pilihmenu(id,aa) {
	window.open("editmenu.php?id="+id,"_self");
//	if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
  //          xmlhttp = new XMLHttpRequest();
    //    } else {
            // code for IE6, IE5
     //       xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
      //  }
     //   xmlhttp.onreadystatechange = function() {
      //      if (this.readyState == 4 && this.status == 200) {
      //           document.getElementById('hasil1').innerHTML=this.responseText;
      //      }
      //  };
	//	   
     //   xmlhttp.open("GET","bukadetail.php?id="+id,true);
     //   xmlhttp.send();
}
function tmenu(){
	if(document.getElementById('menubesar').className=="flex-column flex-shrink-0 p-3 text-white bg-dark hid") {
		document.getElementById('menubesar').className="flex-column flex-shrink-0 p-3 text-white bg-dark";
		document.getElementById('ruang').className="ruang-sempit";
	} else {
		document.getElementById('menubesar').className="flex-column flex-shrink-0 p-3 text-white bg-dark hid";
		document.getElementById('ruang').className="ruang-lebar";
	}
}
function ubah() {
	
	var id=document.getElementById('rekam').value;
	var nama=document.getElementById('nama').value;
	var kat=document.getElementById('categori').value;
	var tipe=document.getElementById('tipe').value;
	var grup=document.getElementById('gmenu').value;
	var harga=document.getElementById('harga').value;
	var gambar=document.getElementById('image-source').value;
	if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                 document.getElementById('hasil1').innerHTML=this.responseText;
            }
        };
		   
        xmlhttp.open("GET","bukadetail.php?id="+id,true);
        xmlhttp.send();
}
var loadFile = function(event) {
	    var output = document.getElementById('output');
	    output.src = URL.createObjectURL(event.target.files[0]);
	  };
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
</body>
</html>
