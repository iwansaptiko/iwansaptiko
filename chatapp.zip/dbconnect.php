<?php
$uname="root";$server="localhost";

$passku="";
$dbname="chatdata";
error_reporting( E_ALL & ~E_DEPRECATED & ~E_NOTICE );
$mysqli = new mysqli($server,$uname,$passku,$dbname);
 if ($mysqli->connect_errno) {
    printf("Connect failed: %s\n", $mysqli->connect_error);
    exit();

}
?>