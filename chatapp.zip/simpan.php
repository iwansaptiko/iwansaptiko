<?php
include_once('dbconnect.php');

$nama=$_POST['nama'];
$token=$_POST['token'];
//echo substr($token,140);
$gbr=substr($token,140);
$res=$mysqli->query("update daftarusers set nama = '$nama' where token='$token'");	


	$nm_file = $_FILES["gambar"]["name"];
		
   
	$tp_file = $_FILES["gambar"]["tmp_name"];
	$sz_file = $_FILES["gambar"]["size"];
	$ty_file = $_FILES["gambar"]["type"];

	$dir = "imgs/".$gbr;
    if (file_exists($dir))
{
$deleted= unlink($dir);
}
	move_uploaded_file($tp_file, $dir);

	// cek status file
	if($sz_file > 500000){
		// tampilkan status gagal karena melebihi batas
		echo $nm_file . " <b>Gagal! file melebihi ukuran. Ukuran maksimal 500kb</b><br>"."<input type='button' value='Kembali' onclick='history.back(-1)' />";
	} else if (file_exists("imgs/" . $nm_file)) {
		// tampilkan status gagal karena file sudah ada
		echo $nm_file . " <b>Gagal! File sudah ada</b><br>" ."<input type='button' value='Kembali' onclick='history.back(-1)' />";
	} else {
		//lokasi file
		$imgFullpath = "http://".$_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"].'?').'/'. "imgs/" . $gbr;
		
		//deskripsi file
		echo "<b>Stored in:</b><a href = '$imgFullpath' target='_blank'> " .$imgFullpath.'<a>';

		echo "<br/><b>File Name:</b> " . $nm_file . "<br>";
		echo "<b>Type:</b> " . $ty_file . "<br>";
		echo "<b>Size:</b> " . $sz_file . " kB<br>";
		echo "<b>Temp file:</b> " . $tp_file . "<br>";
	}
	echo '<a href="index.php?token='.$token.'">Kembali</a>';
?>